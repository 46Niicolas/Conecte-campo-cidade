// Variáveis Globais
let pontoProsperidade;
let obstaculos = [];
let bonus = [];
let pontuacao = 0;
let nivel = 1;
let estadoJogo = 'inicio'; // Estados possíveis: 'inicio', 'jogando', 'ganhou', 'perdeu'

// --- Classe PontoDeProsperidade ---
class PontoDeProsperidade {
  constructor() {
    this.x = width / 2; // Começa no meio, na parte inferior (campo)
    this.y = height - 50;
    this.raio = 20;
    this.velocidadeX = 0;
    this.velocidadeY = -2; // Começa subindo em direção à cidade
    this.cor = color(0, 150, 0); // Verde vibrante para o campo
  }

  // Atualiza a posição do Ponto de Prosperidade
  atualizar() {
    this.x += this.velocidadeX;
    this.y += this.velocidadeY;

    // Limites da tela
    this.x = constrain(this.x, this.raio, width - this.raio);
    this.y = constrain(this.y, this.raio, height - this.raio);
  }

  // Desenha o Ponto de Prosperidade
  desenhar() {
    fill(this.cor);
    noStroke();
    ellipse(this.x, this.y, this.raio * 2);

    // Adiciona uma representação visual que evolui com o nível
    if (nivel >= 2) {
      // Pequenas "folhas" ou "engrenagens" para simbolizar a transformação
      fill(255);
      rect(this.x - 5, this.y - 10, 10, 2);
      rect(this.x - 5, this.y + 8, 10, 2);
    }
    if (nivel >= 3) {
      // Elementos que remetem a estruturas urbanas
      fill(100);
      rect(this.x - 2, this.y - 5, 4, 10);
    }
  }

  // Move o Ponto de Prosperidade com as setas do teclado
  mover(direcao) {
    if (direcao === 'esquerda') {
      this.velocidadeX = -5;
    } else if (direcao === 'direita') {
      this.velocidadeX = 5;
    } else {
      this.velocidadeX = 0; // Para de mover horizontalmente
    }
  }

  // Verifica colisão com outro objeto
  colisao(outroObjeto) {
    let distancia = dist(this.x, this.y, outroObjeto.x, outroObjeto.y);
    return distancia < this.raio + outroObjeto.raio;
  }
}

// --- Classe Obstaculo ---
class Obstaculo {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.raio = 15;
    this.velocidadeY = 1 + nivel * 0.5; // Obstáculos descem mais rápido com o nível
    this.cor = color(200, 50, 50); // Vermelho para obstáculos, simbolizando interrupções
  }

  atualizar() {
    this.y += this.velocidadeY;
  }

  desenhar() {
    fill(this.cor);
    noStroke();
    rectMode(CENTER);
    rect(this.x, this.y, this.raio * 2, this.raio * 2); // Representa desafios
  }
}

// --- Classe Bonus ---
class Bonus {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.raio = 10;
    this.velocidadeY = 1 + nivel * 0.3; // Bônus descem um pouco mais lento que obstáculos
    this.cor = color(50, 200, 50); // Verde claro para bônus, simbolizando soluções
  }

  atualizar() {
    this.y += this.velocidadeY;
  }

  desenhar() {
    fill(this.cor);
    noStroke();
    triangle(this.x, this.y - this.raio, this.x - this.raio, this.y + this.raio, this.x + this.raio, this.y + this.raio); // Representa colaboração e inovação
  }
}

// --- Funções Essenciais do p5.js ---

function setup() {
  createCanvas(600, 800);
  pontoProsperidade = new PontoDeProsperidade();
  frameRate(60);
}

function draw() {
  // Cenário de fundo gradual: campo embaixo, cidade em cima
  setGradient(0, 0, width, height, color(100, 150, 200), color(0, 80, 0), "vertical"); // Azul para o céu/cidade, verde para o campo

  if (estadoJogo === 'inicio') {
    desenharTelaInicio();
  } else if (estadoJogo === 'jogando') {
    atualizarJogo();
    desenharJogo();
  } else if (estadoJogo === 'ganhou') {
    desenharTelaFim('Parabéns! O fluxo da prosperidade chegou à cidade!', color(50, 180, 50));
  } else if (estadoJogo === 'perdeu') {
    desenharTelaFim('Fim de jogo! O fluxo foi interrompido.', color(180, 50, 50));
  }
}

// Função para criar gradiente de fundo
function setGradient(x, y, w, h, c1, c2, axis) {
  noFill();
  if (axis === "vertical") {
    for (let i = y; i <= y + h; i++) {
      let inter = map(i, y, y + h, 0, 1);
      let c = lerpColor(c1, c2, inter);
      stroke(c);
      line(x, i, x + w, i);
    }
  } else if (axis === "horizontal") {
    for (let i = x; i <= x + w; i++) {
      let inter = map(i, x, x + w, 0, 1);
      let c = lerpColor(c1, c2, inter);
      stroke(c);
      line(i, y, i, y + h);
    }
  }
}


function keyPressed() {
  if (estadoJogo === 'inicio' && key === ' ') {
    estadoJogo = 'jogando';
    resetJogo();
  } else if (estadoJogo === 'jogando') {
    if (keyCode === LEFT_ARROW) {
      pontoProsperidade.mover('esquerda');
    } else if (keyCode === RIGHT_ARROW) {
      pontoProsperidade.mover('direita');
    }
  } else if (estadoJogo === 'ganhou' || estadoJogo === 'perdeu') {
    if (key === 'r' || key === 'R') { // Tecla 'R' para reiniciar
      estadoJogo = 'inicio';
    }
  }
}

function keyReleased() {
  if (estadoJogo === 'jogando') {
    if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
      pontoProsperidade.mover('parar');
    }
  }
}

function atualizarJogo() {
  pontoProsperidade.atualizar();

  // Gerar obstáculos e bônus em frequências que aumentam com o nível
  if (frameCount % (60 - nivel * 5) === 0) {
    obstaculos.push(new Obstaculo(random(width), 0));
  }
  if (frameCount % (90 - nivel * 7) === 0) {
    bonus.push(new Bonus(random(width), 0));
  }

  // Atualizar e remover obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].atualizar();
    if (pontoProsperidade.colisao(obstaculos[i])) {
      pontuacao -= 10; // Perde pontos ao colidir com obstáculo
      obstaculos.splice(i, 1); // Remove o obstáculo
      if (pontuacao < 0) { // Condição para perder o jogo
        estadoJogo = 'perdeu';
      }
    }
    if (obstaculos[i].y > height) {
      obstaculos.splice(i, 1); // Remove obstáculos que saem da tela
    }
  }

  // Atualizar e remover bônus
  for (let i = bonus.length - 1; i >= 0; i--) {
    bonus[i].atualizar();
    if (pontoProsperidade.colisao(bonus[i])) {
      pontuacao += 20; // Ganha pontos ao coletar bônus
      bonus.splice(i, 1); // Remove o bônus
    }
    if (bonus[i].y > height) {
      bonus.splice(i, 1); // Remove bônus que saem da tela
    }
  }

  // Condição de vitória: Ponto de Prosperidade chega ao topo da tela (cidade)
  if (pontoProsperidade.y < 50) { // Perto do topo da tela
    nivel++;
    if (nivel <= 3) { // Exemplo: 3 níveis para completar o jogo
      resetNivel();
    } else {
      estadoJogo = 'ganhou';
    }
  }
}

function desenharJogo() {
  pontoProsperidade.desenhar();

  for (let obstaculo of obstaculos) {
    obstaculo.desenhar();
  }

  for (let b of bonus) {
    b.desenhar();
  }

  // Exibir pontuação e nível
  fill(255);
  textSize(24);
  textStyle(BOLD);
  textAlign(LEFT, TOP);
  text(`Pontuação: ${pontuacao}`, 10, 10);
  text(`Nível: ${nivel}`, 10, 40);
}

function desenharTelaInicio() {
  fill(0, 0, 0, 180); // Fundo semi-transparente
  rect(0, 0, width, height);

  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  text('Conecte Campo e Cidade', width / 2, height / 2 - 50);

  textSize(24);
  text('Guie o fluxo de prosperidade do campo para a cidade!', width / 2, height / 2);
  text('Use as setas para mover. Colete bônus e desvie de obstáculos.', width / 2, height / 2 + 40);
  text('Pressione ESPAÇO para começar', width / 2, height / 2 + 100);
}

function desenharTelaFim(mensagem, cor) {
  fill(0, 0, 0, 180);
  rect(0, 0, width, height);

  fill(cor);
  textSize(48);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  text(mensagem, width / 2, height / 2 - 50);

  fill(255);
  textSize(24);
  text(`Pontuação Final: ${pontuacao}`, width / 2, height / 2 + 20);
  text('Pressione R para reiniciar', width / 2, height / 2 + 80);
}

function resetJogo() {
  pontoProsperidade = new PontoDeProsperidade();
  obstaculos = [];
  bonus = [];
  pontuacao = 0;
  nivel = 1;
}

function resetNivel() {
  pontoProsperidade = new PontoDeProsperidade(); // Reinicia a posição do Ponto de Prosperidade
  obstaculos = []; // Limpa obstáculos do nível anterior
  bonus = []; // Limpa bônus do nível anterior
  // A cor do Ponto de Prosperidade pode mudar para refletir a evolução
  if (nivel === 2) {
    pontoProsperidade.cor = color(150, 150, 0); // Amarelo/laranja para algo mais "processado"
  } else if (nivel === 3) {
    pontoProsperidade.cor = color(100, 100, 180); // Azul acinzentado para algo mais "urbano"
  }
}